package com.wxkj.entity;

public class DataBean {

	private String phone;
	private long upLoad;
	private long downLoad;
	private long totalLoad;
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public long getUpLoad() {
		return upLoad;
	}
	public void setUpLoad(long upLoad) {
		this.upLoad = upLoad;
	}
	public long getDownLoad() {
		return downLoad;
	}
	public void setDownLoad(long downLoad) {
		this.downLoad = downLoad;
	}
	public long getTotalLoad() {
		return totalLoad;
	}
	public void setTotalLoad(long totalLoad) {
		this.totalLoad = totalLoad;
	}
	
}
